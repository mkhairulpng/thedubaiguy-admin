import { sqliteTable, integer, text } from "drizzle-orm/sqlite-core";

// Admin users. Passwords are stored ONLY as PBKDF2 hashes (see auth.ts hashPassword).
export const adminUsers = sqliteTable("admin_users", {
  id: integer("id").primaryKey({ autoIncrement: true }),
  email: text("email").notNull().unique(),
  passwordHash: text("password_hash").notNull(),  // pbkdf2$iter$salt$hash — NEVER a plaintext password
  name: text("name"),
  createdAt: text("created_at"),
});
