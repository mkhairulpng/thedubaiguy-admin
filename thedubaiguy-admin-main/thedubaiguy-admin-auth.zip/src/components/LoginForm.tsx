"use client";
import React from "react";

export default function LoginForm({ next = "/admin" }: { next?: string }) {
  const [email, setEmail] = React.useState("");
  const [password, setPassword] = React.useState("");
  const [err, setErr] = React.useState("");
  const [busy, setBusy] = React.useState(false);

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    setErr(""); setBusy(true);
    try {
      const r = await fetch("/api/auth/login", {
        method: "POST", headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email, password }), credentials: "include",
      });
      const d = await r.json();
      if (r.ok) { window.location.href = next; }
      else setErr(d.error || "Login failed");
    } catch { setErr("Network error"); }
    setBusy(false);
  }

  return (
    <form onSubmit={submit} style={{ maxWidth: 360, margin: "0 auto", display: "flex", flexDirection: "column", gap: 12 }}>
      <h1 style={{ textAlign: "center", fontFamily: "Georgia, serif" }}>TheDubaiGuy Admin</h1>
      <input type="email" placeholder="Email" value={email} autoComplete="username"
        onChange={e => setEmail(e.target.value)} required style={inp} />
      <input type="password" placeholder="Password" value={password} autoComplete="current-password"
        onChange={e => setPassword(e.target.value)} required style={inp} />
      <button type="submit" disabled={busy} style={btn}>{busy ? "Signing in…" : "Sign In"}</button>
      {err && <div style={{ color: "#c0392b", fontSize: 13, textAlign: "center" }}>{err}</div>}
    </form>
  );
}
const inp: React.CSSProperties = { padding: "12px 14px", border: "1px solid #d8cdbd", borderRadius: 4, fontSize: 14 };
const btn: React.CSSProperties = { padding: "12px 14px", background: "#14110e", color: "#e0bd79", border: "none", borderRadius: 4, cursor: "pointer", letterSpacing: 1, textTransform: "uppercase", fontSize: 13 };
